import { test, expect } from '@fixtures';

test.describe('Declaration page', { tag: '@duplicated-in-frontend' }, () => {
  test.beforeEach(async ({ animalsSeededJourney, animalsPages }) => {
    const referenceNumber = await animalsSeededJourney.createDraftNotification('readyToSubmit');
    await animalsSeededJourney.resumeInUi(referenceNumber, animalsPages.notificationView);
    await animalsPages.notificationView.continueButton.click();
    await animalsPages.declaration.heading.waitFor();
  });

  test('renders the page controls', async ({ animalsPages }) => {
    await expect(animalsPages.declaration.heading).toBeVisible();
    await expect(animalsPages.declaration.confirmation).toBeVisible();
    await expect(animalsPages.declaration.continueButton).toBeVisible();
  });

  test('shows an error summary when submitted unconfirmed', async ({ pages, animalsPages }) => {
    await animalsPages.declaration.continueButton.click();

    await expect(pages.page.getByRole('heading', { name: 'There is a problem' })).toBeVisible();
  });
});
